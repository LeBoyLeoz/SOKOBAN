#include "interface.h"

using namespace std;
using namespace sf;

Interface::Interface()
{
    string levelsave;
    cout << "Entrez le nom complet du niveau" << endl;
    cin >> levelsave;
    int height = 0; int width = 0;
    vector<int> level;


    ifstream nivax(levelsave, ios::in);

    if(nivax) //lecture du .txt
    {
        string line;
        while (getline(nivax, line))
        {
            height ++;
            width = line.size();
            for(int i = 0; i < width; i ++)
            {
                if(line.at(i) == '0') level.push_back(0);
                if(line.at(i) == '1') level.push_back(1);
                if(line.at(i) == '2') level.push_back(2);
                if(line.at(i) == '3') level.push_back(3);
                if(line.at(i) == '4') level.push_back(4);
            }
        }
    }
    else
        cout << "erreur de l'ouverture de " << levelsave << endl;

    m_game.load(level, width, height);
    m_screen.load(&level, width, height);
}

void Interface::run()
{
    RenderWindow window(VideoMode(m_game.getSize().x * 40, m_game.getSize().y * 40), "S O K O B A N");

    while (window.isOpen())
    {
        bool kreleased = true;
        Event event;
        while (window.pollEvent(event))
        {

            if (event.type == Event::Closed or Keyboard::isKeyPressed(Keyboard::Escape))
                window.close();

            if (Keyboard::isKeyPressed(Keyboard::Z) and kreleased)
            {
                m_game.playerMove(0);
                m_tiles = m_game.getLevel();
                m_screen.load(&m_tiles, m_game.getSize().x, m_game.getSize().y);
                kreleased = false;
            }
            if (Keyboard::isKeyPressed(Keyboard::S) and kreleased)
            {
                m_game.playerMove(1);
                m_tiles = m_game.getLevel();
                m_screen.load(&m_tiles, m_game.getSize().x, m_game.getSize().y);
                kreleased = false;
            }
            if (Keyboard::isKeyPressed(Keyboard::Q) and kreleased)
            {
                m_game.playerMove(2);
                m_tiles = m_game.getLevel();
                m_screen.load(&m_tiles, m_game.getSize().x, m_game.getSize().y);
                kreleased = false;
            }
            if (Keyboard::isKeyPressed(Keyboard::D) and kreleased)
            {
                m_game.playerMove(3);
                m_tiles = m_game.getLevel();
                m_screen.load(&m_tiles, m_game.getSize().x, m_game.getSize().y);
                kreleased = false;
            }
            if (Keyboard::isKeyPressed(Keyboard::R))
            {
                m_game.reset();
                m_tiles = m_game.getLevel();
                m_screen.load(&m_tiles, m_game.getSize().x, m_game.getSize().y);
            }
            if (event.type == Event::KeyReleased)
                kreleased = true;

            if (m_game.isCompleted())
                window.close();
        }

        window.clear();
        window.draw(m_screen);
        window.display();
    }
}

#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include "interface.h"

using namespace std;

int main()
{
    Interface interpute;
    interpute.run();

    return 0;
}

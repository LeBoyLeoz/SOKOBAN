#ifndef DEF_INTERFACE
#define DEF_INTERFACE

#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include "SFML/Graphics.hpp"
#include "tilemap.h"
#include "sogame.h"

class Interface
{
public:
                                        Interface();
    void                                run();

private:
    Tilemap                             m_screen;
    Sogame                              m_game;
    std::vector<int>                    m_tiles;
};

#endif // DEF_INTERFACE
